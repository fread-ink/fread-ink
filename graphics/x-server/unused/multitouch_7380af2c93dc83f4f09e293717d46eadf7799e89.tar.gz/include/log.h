/*
 * Copyright 2011 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */

#ifndef LAB126UTILS_LOG_H_INCLUDED_
#define LAB126UTILS_LOG_H_INCLUDED_

#define LLOG_SUBCOMP "GestureEngine"
#define LLOG_G_LOG_MASK gestureengine_g_llog_mask

#include <llog.h>

#define DEBUG_NONE      0
#define DEBUG_LLOG      1 << 0 
#define DEBUG_LLOG_PERF 1 << 2
#define DEBUG_X_LOW     1 << 3
#define DEBUG_X_MEDIUM  1 << 4
#define DEBUG_X_FULL    1 << 5

// Change this to set maximum allowed debug level
#define DEBUG_LEVEL DEBUG_LLOG

#define GE_LLOG_ERROR(str_error_id, err_args_format, err_msg_format, ...)  LLOGS_ERROR(LLOG_SUBCOMP, str_error_id, err_args_format, err_msg_format, ##__VA_ARGS__ )
#define GE_LLOG_WARN(str_error_id, err_args_format, err_msg_format, ...)   LLOGS_WARN(LLOG_SUBCOMP, str_error_id, err_args_format, err_msg_format, ##__VA_ARGS__ )
#define GE_LLOG_INFO(str_error_id, err_args_format, err_msg_format, ...)   LLOGS_INFO(LLOG_SUBCOMP, str_error_id, err_args_format, err_msg_format, ##__VA_ARGS__ )

#if DEBUG_LEVEL > 0
#define DEBUG_INFO(level, fmt, args...) \
 if ((level) & DEBUG_LLOG) \
 { \
   GE_LLOG_WARN("Touch", "", fmt, ## args); \
 } \
else if ((level & DEBUG_LLOG_PERF)) \
 { \
   GE_LLOG_INFO("perfScenario", "", fmt, ## args); \
 }\
else if (((level) & ~DEBUG_LLOG) <= (DEBUG_LEVEL & ~DEBUG_LLOG)) \
 { \
   xf86Msg(X_INFO, "[GestureEngine] " fmt, ## args); \
 }
#else
  #define DEBUG_INFO(level, fmt, args...) //NOP
#endif

unsigned int gettimems();

#endif // LAB126UTILS_LOG_H_INCLUDED_
