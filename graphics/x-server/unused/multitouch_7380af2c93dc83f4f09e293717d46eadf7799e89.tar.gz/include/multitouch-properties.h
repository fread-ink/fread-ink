/*
 * Multitouch X Input Driver Properties
 * Nadim Awad <nawad@lab126.com>
 * Copyright (c)2006-2011 Amazon Technologies.  All rights reserved.
 */

#ifndef __MULTITOUCH_PROPERTIES_H___
#define __MULTITOUCH_PROPERTIES_H___

#define MULTITOUCH_PROP_ORIENTATION "Multitouch Device Orientation"
#define MULTITOUCH_PROP_GRIPSUPR    "Multitouch Grip Suppression"

#endif
